﻿using ConApp5_4_Ex_.Classes;
using ConApp5_4_Ex_.Pages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp5_4_Ex_
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            Button el = new Button();
            el.status = false;
            el.Click();
            */
            StartPage st = new StartPage();
            
           Console.ReadLine();
        }
    }
}
