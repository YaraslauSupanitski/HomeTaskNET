﻿using ConApp5_4_Ex_.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConApp5_4_Ex_.Pages
{
    class StartPage : BasePage
    {
        List<Button> listButton;

        List<BaseElement> otherElements;

        public StartPage()
        {
            string path = $"{Environment.CurrentDirectory}\\..\\..\\Data\\PagesElements.xml";
            listButton = generateButton(path);
        }

        protected List<Button> fillButtonStatus()
        {
            string path = $"{Environment.CurrentDirectory}\\..\\..\\Data\\ButtonsState.xml";
            XDocument xDoc = XDocument.Load(path);
            XElement root = xDoc.Root;
            List<XElement> state = 
            listButton.ForEach(but => xDoc.Element("buttons").Elements("buttons"));
        }
    }
}
