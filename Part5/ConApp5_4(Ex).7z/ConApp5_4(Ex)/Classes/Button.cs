﻿using ConApp5_4_Ex_.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp5_4_Ex_.Classes
{
    class Button : BaseElement, IClickable
    {
        public Button(string name, string status)
        {
            this.Name = name;
            this.status = Boolean.Parse(status);

        }
        public Button(string name)
        {
            this.Name = name;

        }
        public Button()
        {

        }

        public string Click()
        {
            if (!this.status)
            {
                FormatException ex = new FormatException("Element Disabled");
                try
                {
                    throw ex;
                    Console.WriteLine("all ok");
                }
                catch (FormatException e) {
                    Console.WriteLine(e);
                }
                //generate Ex
            }
            return this.Name;
        }
    }
}
