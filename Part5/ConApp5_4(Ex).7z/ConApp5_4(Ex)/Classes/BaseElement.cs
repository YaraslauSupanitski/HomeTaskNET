﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConApp5_4_Ex_.Classes
{
    abstract class BaseElement
    {
        public string Name { get; set; }
        public bool status = false;
    }
}
